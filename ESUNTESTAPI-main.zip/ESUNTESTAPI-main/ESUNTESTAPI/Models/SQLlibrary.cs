﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace ESUNTEST
{
    public static class SQLlibrary
    {
		/// <summary>
		/// 大批寫入
		/// </summary>
		/// <param name="dtSource">寫入的資料dataTable</param>
		/// <param name="TableNmae">標的名稱</param>
		/// <param name="conn">sql連線</param>
		/// <returns></returns>
		public static bool ExecSqlBulkCopy(DataTable dtSource,string TableNmae, SqlConnection conn)
		{

			try
			{

				SqlTransaction sqlTrans = conn.BeginTransaction();
				try
				{
					using (SqlBulkCopy bulkCopy = new SqlBulkCopy(conn, SqlBulkCopyOptions.KeepIdentity, sqlTrans))
					{

						DataTable dt = dtSource;

						bulkCopy.DestinationTableName = TableNmae;

						bulkCopy.BatchSize = 1000;

						bulkCopy.BulkCopyTimeout = 60;

						try

						{

							bulkCopy.WriteToServer(dt);

						}

						catch (Exception ex)

						{

							sqlTrans.Rollback();

							return false;

						}

						sqlTrans.Commit();

						return true;
					}
				}
				catch (Exception ex)
				{
					sqlTrans.Rollback();
					throw ex;
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}

		}
	}
}
