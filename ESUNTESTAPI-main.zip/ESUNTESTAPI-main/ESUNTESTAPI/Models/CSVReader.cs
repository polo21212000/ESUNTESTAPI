﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESUNTEST
{
    public class CSVReader
    {
        private Stream objStream;
        private StreamReader objReader;

        //add name space System.IO.Stream
        public CSVReader()
        {

        }
        public CSVReader(Stream filestream) : this(filestream, null) { }
        public CSVReader(StreamReader strReader)
        {
            this.objReader = strReader;
        }
        public CSVReader(Stream filestream, Encoding enc)
        {
            this.objStream = filestream;
            //check the Pass Stream whether it is readable or not
            if (!filestream.CanRead)
            {
                return;
            }
            objReader = (enc != null) ? new StreamReader(filestream, enc) : new StreamReader(filestream);
        }
        //parse the Line
        public string[] GetCSVLine()
        {
            string data = objReader.ReadLine();
            if (data == null) return null;
            if (data.Length == 0) return new string[0];
            //System.Collection.Generic
            ArrayList result = new ArrayList();
            //parsing CSV Data
            ParseCSVData(result, data);
            return (string[])result.ToArray(typeof(string));
        }

        public bool ParseCSVData(ArrayList result, string data)
        {
            try
            {
                int position = -1;
                while (position < data.Length)
                {
                    result.Add(ParseCSVField(ref data, ref position));
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        private string ParseCSVField(ref string data, ref int StartSeperatorPos)
        {
            if (StartSeperatorPos == data.Length - 1)
            {
                StartSeperatorPos++;
                return "";
            }

            int fromPos = StartSeperatorPos + 1;
            if (data[fromPos] == '"')
            {
                int nextSingleQuote = GetSingleQuote(data, fromPos + 1);
                int lines = 1;
                while (nextSingleQuote == -1)
                {
                    data = data + "\n" + objReader.ReadLine();
                    nextSingleQuote = GetSingleQuote(data, fromPos + 1);
                    lines++;
                    if (lines > 20)
                        throw new Exception("lines overflow: " + data);
                }
                StartSeperatorPos = nextSingleQuote + 1;
                string tempString = data.Substring(fromPos + 1, nextSingleQuote - fromPos - 1);
                tempString = tempString.Replace("'", "''");
                return tempString.Replace("\"\"", "\"");
            }

            int nextComma = data.IndexOf(',', fromPos);
            if (nextComma == -1)
            {
                StartSeperatorPos = data.Length;
                return data.Substring(fromPos);
            }
            else
            {
                StartSeperatorPos = nextComma;
                return data.Substring(fromPos, nextComma - fromPos);
            }
        }

        private int GetSingleQuote(string data, int SFrom)
        {
            int i = SFrom - 1;
            while (++i < data.Length)
                if (data[i] == '"')
                {
                    if (i < data.Length - 1 && data[i + 1] == '"')
                    {
                        i++;
                        continue;
                    }
                    else
                        return i;
                }
            return -1;
        }
        /// <summary>
        /// csv轉dataTable
        /// </summary>
        /// <param name="datas">原始資料陣列string[]</param>
        /// <param name="TableName">得到的dataTABLE名稱</param>
        /// <param name="delimiter">資料陣列split字元</param>
        /// <returns></returns>
        public DataTable CsvConvertToDataTable(string[] datas,string TableName, string delimiter)
        {
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();
            try
            {
                string[] columns = datas[0].Split(delimiter.ToCharArray());
                ds.Tables.Add(TableName);
                foreach (string col in columns)
                {
                    bool added = false;
                    string next = "";
                    int i = 0;
                    while (!added)
                    {
                        string columnname = col + next;
                        columnname = columnname.Replace("#", "");
                        columnname = columnname.Replace("'", "");
                        columnname = columnname.Replace("&", "");

                        if (!ds.Tables[TableName].Columns.Contains(columnname))
                        {
                            ds.Tables[TableName].Columns.Add(columnname.ToUpper().Replace(@"""", ""));
                            added = true;
                        }
                        else
                        {
                            i++;
                            next = "_" + i.ToString();
                        }
                    }
                }
                ds.Tables[TableName].Columns.Add("寫入日期");
                for (int i = 1; i < datas.Length; i++)
                {
                    string[] items = datas[i].Split(delimiter.ToCharArray());
                    string[] ritem = new string[items.Length+1];
                    int f = 0;
                    foreach (string ww in items)
                    {
                        ritem[f] = ww.Replace(@"""", "").Trim();
                        f++;
                    }
                    ritem[items.Length] = DateTime.Now.ToString("yyyy-MM-dd");
                    ds.Tables[TableName].Rows.Add(ritem);
                }

                dt = ds.Tables[0];
                #region 處理成需要的格式
                dt.Columns.RemoveAt(0);
                using (DataTable tempA = dt.Copy())
                {
                    //移除前三
                    tempA.Columns.RemoveAt(0);
                    tempA.Columns.RemoveAt(0);
                    tempA.Columns.RemoveAt(0);
                    foreach (DataColumn dc in tempA.Columns)
                    {
                        if (dc.ColumnName == "寫入日期")
                        {
                            continue;
                        }
                        dt.Columns.Remove(dc.ColumnName);
                    }
                    for (int i = 0; i < tempA.Columns.Count; i++)
                    {
                        tempA.Columns[i].ColumnName = dt.Columns[i].ColumnName;
                    }
                    dt.Merge(tempA);
                } 
                #endregion
                return dt;
            }
            catch(Exception ex) {
                return null;
            }
        }



    }
}
