﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ESUNTESTAPI.Models;
using Microsoft.Extensions.Configuration;
using ESUNTEST;
using System.Net;
using System.Data;
using System.Data.SqlClient;
using Newtonsoft.Json;

namespace ESUNTESTAPI.Controllers
{
    public class ReportController : Controller
    {
        private readonly ILogger<ReportController> _logger;
        private IConfiguration ConfigRoot;
        public ReportController(ILogger<ReportController> logger, IConfiguration configRoot)
        {
            ConfigRoot = (IConfigurationRoot)configRoot;
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }  
        public IActionResult GetOpenData()
        {
            string URL = "";
            string TempData = "";
            CSVReader csv = null;
            string[] datas = null;
            string[] lineStrs = null;
            bool isSTOCKCodeLine = false;
            string sqlstr = "";
            string jsonResult = "";

            try
            {

                URL = @"https://www.twse.com.tw/zh/ETFReport/ETFRank?response=open_data";

                using (WebClient wClient = new WebClient())
                {
                    TempData = wClient.DownloadString(URL);
                }
                csv = new CSVReader();
                lineStrs = TempData.Trim().Split('\n');
                using (DataTable Origin = csv.CsvConvertToDataTable(lineStrs, "EST", ","))
                {
                    //處理格式forSECHMA
                   
                    if (Origin.Rows.Count > 0)
                    {
                        using (SqlConnection conn = new SqlConnection(ConfigRoot.GetConnectionString("ESUNConnection")))
                        {

                            conn.Open();
                            sqlstr = " DELETE FROM [ESUN].[dbo].[EST] WHERE ES004 = @ES004 ";
                            using (SqlCommand cmd = new SqlCommand(sqlstr, conn))
                            {
                                cmd.Parameters.AddWithValue("@ES004", DateTime.Now.ToString("yyyy-MM-dd"));
                                cmd.ExecuteNonQuery();
                            }
                            SQLlibrary.ExecSqlBulkCopy(Origin, Origin.TableName, conn);
                            conn.Close();
                        }
                        Origin.Columns.Remove("股票代號");
                        Origin.Columns.Remove("寫入日期");
                        jsonResult = JsonConvert.SerializeObject(Origin, Formatting.Indented);

                    }

                }
            }
            catch (Exception ex)
            {
            }

            return Ok(jsonResult);
        }




    }
}
