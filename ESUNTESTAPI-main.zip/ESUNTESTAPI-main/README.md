# ESUNTESTAPI
測試考題


因沒用過SSDT 資料庫請使用DOC文件夾的SECHMA建立對應表單
再更改appsettings.json的連線字串即可使用